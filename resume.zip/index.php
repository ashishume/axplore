<?php
   $m="";
if(isset($_POST['submit_contact']))
{
    $name=$_POST['name'];
    $email=$_POST['email'];
    $message=$_POST['message'];
    
    $text="
    Name: $name
    
    Email ID: $email
    
    Subject: AXPlORE CONTACT FORM
    
    Message: 
    
    $message
    
    ";
    
    mail("ashishume@gmail.com","Axplore Contact","$text","From:axplore@axploreworld.com");
    
    if(mail()==true)
    {
        
    }else{
        echo $m= "<p>THANKS YOU, WE HAVE RECEIVED YOUR QUERY. WE WILL CONTACT YOU SOON.</p>";
    }
}
?>



<!DOCTYPE html>
<html>
<head>
	<title>Axplore World</title>
	<!--fonts-->
		<link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic' rel='stylesheet' type='text/css'>
    
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    
    
	<!--//fonts-->
		<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
		<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<!-- for-mobile-apps -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- //for-mobile-apps -->
	<!-- js -->
		<script type="text/javascript" src="js/jquery.min.js"></script>
	<!-- js -->
	<!-- start-smooth-scrolling -->
		<script type="text/javascript" src="js/move-top.js"></script>
		<script type="text/javascript" src="js/easing.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
		</script>
	<!-- start-smooth-scrolling -->

</head>
<body>
<!-- banner -->
<div class="banner" id="home">
	<div class="container">
		<div class="top-header row">
			<script src="js/classie.js"></script>
			<!--top-nav---->
			<div class="logo">
				<a href="index"><img style="max-height:70px;max-width: 70px; " src="images/axplore.png" alt=""/></a>
			</div>
			<div class="top-nav">
<!--
				<div class="nav-icon">
					    <a href="#" class="right_bt" id="activator"><span> </span> </a>
				</div>
-->
<!--
				<div class="box" id="box">
					<div class="box_content">
						<div class="box_content_center">
							<div class="form_content">
								<div class="menu_box_list">
									<ul>
										<li><a class="scroll" href="#home"><span>home</span></a></li>
										<li><a class="scroll" href="#about"><span>about</span></a></li>
										<li><a class="scroll" href="#services"><span>services</span></a></li>
										<li><a class="scroll" href="#portfolio"><span>portfolio</span></a></li>
										<li><a class="scroll" href="#testimonial"><span>Testimonial</span></a></li>
										<li><a class="scroll" href="#blog"><span>blog</span></a></li>
										<li><a class="scroll" href="#contact"><span>Contact</span></a></li>
										<div class="clearfix"> </div>
									</ul>
								</div>
								<a class="boxclose" id="boxclose"> <span> </span></a>
							</div>
						</div>
					</div>
				</div>
-->
			</div>
			<!---start-click-drop-down-menu----->
			        <!----start-dropdown--->
			         <script type="text/javascript">
						var $ = jQuery.noConflict();
							$(function() {
								$('#activator').click(function(){
									$('#box').animate({'top':'0px'},900);
								});
								$('#boxclose').click(function(){
								$('#box').animate({'top':'-1000px'},900);
								});
							});
							$(document).ready(function(){
							//Hide (Collapse) the toggle containers on load
							$(".toggle_container").hide();
							//Switch the "Open" and "Close" state per click then slide up/down (depending on open/close state)
							$(".trigger").click(function(){
								$(this).toggleClass("active").next().slideToggle("slow");
									return false; //Prevent the browser jump to the link anchor
							});

						});
					</script>
			<!---//End-click-drop-down-menu----->
			<div class="clearfix"> </div>
		</div>
		<div class="banner-info">
			<div class="banner-left">
				<img src="images/ashish.jpg" class="img-responsive" style="border-radius: 500px;max-height: 200px;max-width: 200px;"   alt=""/>
			</div>
			<div class="banner-right">
				<h1>Hey I'm <br>ASHISH DEBNATH</h1>
				<div class="border"></div>
				<h2>WEB DEVELOPER</h2>
				<a href="resume.pdf" target="_blank">DOWNLOAD MY RESUME</a>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!--/header-banner-->
<!--about-->
<div class="about text-center" id="about">
	<div class="container">
		<h3>ABOUT ME</h3>
		<div class="strip text-center"><img src="images/about.png" alt=" "/></div>
		<p style="">Hi my name is Ashish Debnath, Im persuing B.Tech from Chandigarh Engineering College, Landran
			in Electronics department. Im 21 years old. I like programming such as working in alogrithms in c++ or java,
			I am a web developer having 1 year of experience. My hobbies include surfing on Quora, online gaming,
			 watching TV series etc. I have worked on various projects based on web. Some of the projects are mentioned below.
			 Im a patient listener, confident speaker, team worker and trust worthy person.

		</p>
		<ul>
			<h2>Connect with me</h2><br>
			<li><a class="fb" href="https://www.facebook.com/ashishdevume" target="_blank"></a></li>
			<li><a class="twit" href="https://twitter.com/ashishume" target="_blank"></a></li>
			<li><a class="in" href="https://www.linkedin.com/in/ashishume/" target="_blank"></a></li>
			<li><a class="goog" href="https://plus.google.com/+AshishDebnath" target="_blank"></a></li>
<!--			<li><a class="pin" href="#" target="_blank"></a></li>-->
<!--			<li><a class="insta" href="https://www.instagram.com/ashishdevume/" target="_blank"></a></li>-->
		</ul>
	</div>
</div>
<!--//about-->

<!--    #0d526d-->
<!--<div class="about-back"></div>-->

<!--<div class="my-skill-back"></div>-->
<!--education-->
<div class="education text-center">
	<div class="container">
		<div class="edu-info">
			<h3>EDUCATION</h3>
		</div>
		<div class="strip text-center"><img src="images/edu.png" alt=" "/></div>
		<div class="edu-grids">
			<div class="col-md-4 edu-grid">
				<p>2012 - 2013</p><span>Class 10</span>
				<img src="images/arrow.png" alt=""/>
				<div  class="edu-border">
					<div class="edu-grid-master">
<!--						<h3>CBSE Board</h3>-->
						<h4>Kendriya Vidyalaya Coochbehar</h4>
					</div>
					<div class="edu-grid-info">
						<h5>I have completed my class 10 from CBSE board and scored 89.8%</h5>
					</div>
				</div>
			</div>
			<div class="col-md-4 edu-grid">
				<p>2014 - 2015</p><span>Class 12</span>
				<img src="images/arrow.png" alt=""/>
				<div class="edu-border">
					<div class="edu-grid-master">
<!--						<h3>MASTER DEGREE OF COMPUTER SCIENCE</h3>-->
						<h4>Kendriya Vidyalaya Coochbehar</h4>
					</div>
					<div class="edu-grid-info">
						<h5>I have completed my senior secondary from CBSE board and able to score 81.6%</h5>
					</div>
				</div>
			</div>
			<div class="col-md-4 edu-grid">
				<p>2015 - 2019</p><span>Graduation</span>
				<img src="images/arrow.png" alt=""/>
				<div class="edu-border">
					<div class="edu-grid-master">
<!--						<h3></h3>-->
						<h4>Chandigarh Engineering College,Landran</h4>
					</div>
					<div class="edu-grid-info">
						<h5>Im currently persuing my Btech from CEC landran in Electronics Department.</h5>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>

</div>
<!--//education-->
<div class="strip-border"><p></p></div>
<!--work-->
<!--
<div class="work-experience text-center">

	<div class="container">
		<div class="work-info">
			<h3>WORK EXPERIENCE</h3>
		</div>
		<div class="strip text-center"><img src="images/work.png" alt=" "/></div>
		<div class="work-grids">
			<div class="col-md-4 w-grid">
				<div class="work-grid">
					<h3>2013 - Now</h3>
					<div class="work-grid-info">
						<h4>Google</h4>
						<h5>Visual Designer</h5>
						<p>Now that there is the Tec-9, a crappy spray gun from South Miami.
						This gun is advertised as the most popular gun in American crime.
						Do you believe that shit? It actually says that in the little book
						that comes with it: the most popular gun in</p>
					</div>
				</div>
			</div>
			<div class="col-md-4 w-grid">
				<div class="work-grid">
					<h3>2013 - Now</h3>
					<div class="work-grid-info">
						<h4>Google</h4>
						<h5>Visual Designer</h5>
						<p>Now that there is the Tec-9, a crappy spray gun from South Miami.
						This gun is advertised as the most popular gun in American crime.
						Do you believe that shit? It actually says that in the little book
						that comes with it: the most popular gun in</p>
					</div>
				</div>
			</div>
			<div class="col-md-4 w-grid">
				<div class="work-grid">
					<h3>2013 - Now</h3>
					<div class="work-grid-info">
						<h4>Google</h4>
						<h5>Visual Designer</h5>
						<p>Now that there is the Tec-9, a crappy spray gun from South Miami.
						This gun is advertised as the most popular gun in American crime.
						Do you believe that shit? It actually says that in the little book
						that comes with it: the most popular gun in</p>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
-->
<!--//work-->
<div class="services-back"></div>

<!--services-->
<div class="services text-center" id="services">
	<div class="container">
		<div class="ser-info">
			<h3>SKILLS</h3>
		</div>
		<div class="strip text-center"><img src="images/ser.png" alt=" "/></div>
		<div class="ser-grids">
			<div class="col-md-4 ser-grid">
				<div class="ser-imagea"></div>
				<h3>Web Designer</h3>
				<p>I have desgined lot of websites using CSS3 and JQuery</p>
			</div>
			<div class="col-md-4 ser-grid">
				<div class="ser-imageb"></div>
				<h3>Photoshop Design</h3>
				<p>I have created lots of logos and designed websites using Photoshop. I can also edit pictures using photoshop</p>
			</div>
<!--
			<div class="col-md-3 ser-grid">
				<div class="ser-imagec"></div>
				<h3></h3>
				<p>I'm gonna shoot you in the head
				then and there. Then I'm gonna shoot
				that bitch in the kneecaps.</p>
			</div>
-->
			<div class="col-md-4 ser-grid">
				<div class="ser-imaged"></div>
				<h3>Website Development</h3>
				<p>I even develop the backend of a website, which includes PHP, Javascript etc.</p>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!--//services-->
<!--portfolio-->
<div class="gallery-section text-center" id="portfolio">
	<div class="container">
		<h3>PORTFOLIO</h3>
		<div class="strip text-center"><img src="images/port.png" alt=" "/></div>
		<p>These are the samples of my work in which I have spent lots of work hours and gave the best possible outcome.</p>
		<div class="gallery-grids">
			<div class="top-gallery">
				<div class="col-md-4 gallery-grid gallery1">
<!--					<a href="single.html" class="swipebox">-->
                        <img src="images/plumbing-service-1.jpg" class="img-responsive" alt="/">
						<div class="textbox">
							<h4>Axplore Services</h4>
							<p>WEB DESIGN</p>
							<div class="button"><a href="images/p1.jpg" class="swipebox"></a>
                            <a href="axplore_service" target="_blank">View</a>
                            </div>
						</div>
<!--                    </a>-->
				</div>

				<div class="col-md-4 gallery-grid gallery1">
<!--					<a href="" class="swipebox">-->
                        <img src="images/5-3.jpg" class="img-responsive" alt="/">
						<div class="textbox">
							<h4>Vyapar</h4>
							<p>WEB DESIGN</p>
							<div class="button"><a href="images/p3.jpg" class="swipebox"></a>
                             <a href="vyapar" target="_blank">View</a>
                            </div>
						</div>
<!--                    </a>-->
				</div>
				<div class="col-md-4 gallery-grid gallery1">
<!--					<a href="" class="swipebox">-->
                        <img src="images/yourstory-shopatplaces-funding.jpg" class="img-responsive" alt="/">
						<div class="textbox">
							<h4>Axient Corporation</h4>
							<p>WEB DESIGN</p>
							<div class="button"><a href="images/p4.jpg" class="swipebox"></a>
                             <a href="axient_corporation" target="_blank">View</a>
                            </div>
						</div>
<!--                    </a>-->
				</div>
				<div class="col-md-4 gallery-grid gallery1">
<!--					<a href="" class="swipebox">-->
                        <img src="images/00_Top-Travel-Trends-for-2018_209155915_06photo_FT.jpg" class="img-responsive" alt="/">
						<div class="textbox">
							<h4>Travel</h4>
							<p>WEB DESIGN</p>
							<div class="button"><a href="images/p5.jpg" class="swipebox"></a>
                             <a href="cndtourtravel" target="_blank">View</a>
                            </div>
						</div>
<!--                    </a>-->
				</div>

				<div class="clearfix"> </div>
			</div>
				<link rel="stylesheet" href="css/swipebox.css">
				<script src="js/jquery.swipebox.min.js"></script>
					<script type="text/javascript">
						jQuery(function($) {
							$(".swipebox").swipebox();
						});
					</script>
		</div>
	</div>
</div>
<!--//portfolio-->
<!--process-->
<div class="process text-center">
	<div class="container">
		<h3>Prgramming Knowledge</h3>
		<div class="strip text-center"><img src="images/pro.png" alt=" "/></div><br>
        <div class="col-sm-6" style="">
            
            
        <div class="progress">
  <div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" aria-valuenow="70"
  aria-valuemin="0" aria-valuemax="100" style="width:70%">
    <span class="">Java (70%) </span>
  </div>
</div>
        <br>    
              <div class="progress">
  <div class="progress-bar progress-bar-danger progress-bar-striped active" role="progressbar" aria-valuenow="70"
  aria-valuemin="0" aria-valuemax="100" style="width:90%">
    <span class="">C++ (90%) </span>
  </div>
</div>
           <br> 
              <div class="progress">
  <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="70"
  aria-valuemin="0" aria-valuemax="100" style="width:80%">
    <span class="">SQL (80%) </span>
  </div>             
</div>
        <br>
    <div class="progress">
  <div class="progress-bar progress-bar-warning progress-bar-striped active" role="progressbar" aria-valuenow="70"
  aria-valuemin="0" aria-valuemax="100" style="width:60%">
    <span class="">JavaScript (60%) </span>
  </div>        
            </div>    <br>  
        </div><!--        ROW 1-->
        
        <div class="col-sm-6" style="">

            <div class="progress">
  <div class="progress-bar progress-bar-warning progress-bar-striped active" role="progressbar" aria-valuenow="70"
  aria-valuemin="0" aria-valuemax="100" style="width:75%">
    <span class="">PHP (75%)</span>
  </div>
</div>  <br>
        
            <div class="progress">
  <div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" aria-valuenow="70"
  aria-valuemin="0" aria-valuemax="100" style="width:90%">
    <span class="">HTML5 (90%)</span>
  </div>
</div>  <br>
            
            <div class="progress">
  <div class="progress-bar progress-bar-danger progress-bar-striped active" role="progressbar" aria-valuenow="70"
  aria-valuemin="0" aria-valuemax="100" style="width:80%">
    <span class="">CSS3 (80%)</span>
  </div>
</div>  <br>
            
            <div class="progress">
  <div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" aria-valuenow="70"
  aria-valuemin="0" aria-valuemax="100" style="width:30%">
    <span class="">Android (30%)</span>
  </div>
</div>  
<br>
            
            
        
        </div><!--        ROW 2-->
        
        
	</div>
</div>
<!--//process-->

<!--<div class="process-back"></div>-->
<!--testimonials-->
<!--
<div class="testimonials" id="testimonial">
	<div class="container">
		<h3>TESTIMONIAL</h3>
		<div class="strip text-center"><img src="images/test.png" alt=" "/></div>
-->
			<!-- responsiveslides -->
<!--					<script src="js/responsiveslides.min.js"></script>-->
						<script>
							// You can also use "$(window).load(function() {"
//							$(function () {
//							 // Slideshow 4
//							$("#slider3").responsiveSlides({
//								auto: true,
//								pager: false,
//								nav: true,
//								speed: 500,
//								namespace: "callbacks",
//								before: function () {
//							$('.events').append("<li>before event fired.</li>");
//							},
//							after: function () {
//								$('.events').append("<li>after event fired.</li>");
//								}
//								});
//								});
						</script>
			<!-- responsiveslides -->
<!--
			<div  id="top" class="callbacks_container">
					<ul class="rslides" id="slider3">
						<li>
							<div class="test-banner">
								<img class="quoa" src="images/quo2.png" alt=""/>
								<div class="test-left">
									<img src="images/7.png" alt=""/>
								</div>
								<div class="test-right">
									<p>However unreal it may seem, we are connected,
									you and I. We're on the same curve, just on opposite ends.</p>
									<h4>Sam L. J. - Pulp Fiction</h4>
								</div>
								<div class="clearfix"></div>
								<img class="quo" src="images/quo1.png" alt=""/>
							</div>
						</li>
						<li>
							<div class="test-banner">
								<img class="quoa" src="images/quo2.png" alt=""/>
								<div class="test-left">
									<img src="images/eee.png" alt=""/>
								</div>
								<div class="test-right">
									<p>However unreal it may seem, we are connected,
									you and I. We're on the same curve, just on opposite ends.</p>
									<h4>Sam L. J. - Pulp Fiction</h4>
								</div>
								<div class="clearfix"></div>
								<img class="quo" src="images/quo1.png" alt=""/>
							</div>
						</li>
					</ul>
			</div>

	</div>
</div>
-->
<!--testimonials-->
<!--clients-->
<!--
<div class="clients text-center">
	<div class="container">
		<h4>Clients</h4>
		<div class="strip-line"></div>
		<div class="client-grids">
			<div class="col-md-4 cl-grid">
				<div class="client-grid">
					<img src="images/10.png" alt=""/>
				</div>
			</div>
			<div class="col-md-4 cl-grid">
				<div class="client-grid">
					<img src="images/11.png" alt=""/>
				</div>
			</div>
			<div class="col-md-4 cl-grid">
				<div class="client-grid">
					<img src="images/12.png" alt=""/>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
-->
<!--clients-->
<!--<div class="client-back"></div>-->
<!--blog-->
<div class="blog" id="blog">
<!--
	<div class="container">
		<div class="blog-info text-center">
			<h3>BLOG</h3>
			<div class="strip text-center"><img src="images/blog.png" alt=" "/></div>
-->
<!--
		</div>
		<div class="blog-grids">
			<div class="col-md-4 blog-text-info">
				<div class="blog-grid">
					<a href="single.html"><img src="images/a.jpg" alt=""/></a>
					<div class="blog-text">
						<a href="single.html">Nature is lethal but it doesn't hold a candle to man.</a>
						<div class="stripa"></div>
						<p>Your bones don't break, mine do. That's clear. Your cells react to bacteria
						and viruses differently than mine. You don't get sick, I do.</p>
					</div>

					<div class="blog-para">
							<ul>
								<li><a href="#">3 Comments</a></li>
								<li><a href="#">8 Share</a></li>
							</ul>
					</div>
					<div class="blog-pos">
						<p>5<span>May</span></p>
					</div>
				</div>
			</div>
			<div class="col-md-4 blog-text-info">
				<div class="blog-grid">
					<a href="single.html"><img src="images/b.jpg" alt=""/></a>
					<div class="blog-text">
						<a href="single.html">Nature is lethal but it doesn't hold a candle to man.</a>
						<div class="stripa"></div>
						<p>Your bones don't break, mine do. That's clear. Your cells react to bacteria
						and viruses differently than mine. You don't get sick, I do.</p>
-->
<!--
					</div>

					<div class="blog-para">
							<ul>
								<li><a href="#">3 Comments</a></li>
								<li><a href="#">8 Share</a></li>
							</ul>
					</div>
					<div class="blog-pos">
						<p>5<span>May</span></p>
					</div>
				</div>
			</div>
			<div class="col-md-4 blog-text-info">
				<div class="blog-grid">
					<a href="single.html"><img src="images/c.jpg" alt=""/></a>
					<div class="blog-text">
						<a href="single.html">Nature is lethal but it doesn't hold a candle to man.</a>
						<div class="stripa"></div>
						<p>Your bones don't break, mine do. That's clear. Your cells react to bacteria
						and viruses differently than mine. You don't get sick, I do.</p>
					</div>

					<div class="blog-para">
							<ul>
								<li><a href="#">3 Comments</a></li>
								<li><a href="#">8 Share</a></li>
							</ul>
					</div>
					<div class="blog-pos">
						<p>5<span>May</span></p>
					</div>
-->
<!--
				</div>
			</div>
			<div class="col-md-4 blog-text-info">
				<div class="blog-grid">
					<a href="single.html"><img src="images/a.jpg" alt=""/></a>
					<div class="blog-text">
						<a href="single.html">Nature is lethal but it doesn't hold a candle to man.</a>
						<div class="stripa"></div>
						<p>Your bones don't break, mine do. That's clear. Your cells react to bacteria
						and viruses differently than mine. You don't get sick, I do.</p>
					</div>

					<div class="blog-para">
							<ul>
								<li><a href="#">3 Comments</a></li>
								<li><a href="#">8 Share</a></li>
							</ul>
					</div>
					<div class="blog-pos">
						<p>5<span>May</span></p>
					</div>
				</div>
			</div>
			<div class="col-md-4 blog-text-info">
				<div class="blog-grid">
					<a href="single.html"><img src="images/b.jpg" alt=""/></a>
					<div class="blog-text">
						<a href="single.html">Nature is lethal but it doesn't hold a candle to man.</a>
						<div class="stripa"></div>
						<p>Your bones don't break, mine do. That's clear. Your cells react to bacteria
						and viruses differently than mine. You don't get sick, I do.</p>
					</div>

					<div class="blog-para">
							<ul>
-->
<!--
								<li><a href="#">3 Comments</a></li>
								<li><a href="#">8 Share</a></li>
							</ul>
					</div>
					<div class="blog-pos">
						<p>5<span>May</span></p>
					</div>
				</div>
			</div>
			<div class="col-md-4 blog-text-info">
				<div class="blog-grid">
					<a href="single.html"><img src="images/c.jpg" alt=""/></a>
					<div class="blog-text">
						<a href="single.html">Nature is lethal but it doesn't hold a candle to man.</a>
						<div class="stripa"></div>
						<p>Your bones don't break, mine do. That's clear. Your cells react to bacteria
						and viruses differently than mine. You don't get sick, I do.</p>
					</div>

					<div class="blog-para">
							<ul>
								<li><a href="#">3 Comments</a></li>
								<li><a href="#">8 Share</a></li>
							</ul>
					</div>
					<div class="blog-pos">
						<p>5<span>May</span></p>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
-->
<!--//blog-->
<!--<div class="contact-back"></div>-->
<!--contact-->

<div class="contact" id="contact">
	<div class="container">
		<div class="contact-info text-center" >
			<h3 style="color: white;">CONTACT</h3>
			<div class="strip text-center" style="color: white;"><img src="images/con1.png" alt=" "/></div>
		</div>
		<div class="contact-grids">
			<div class="col-md-5 contact-left">
				<h3 style="color: white;">Say Hi to Me</h3>
				<div class="stripb"></div>
				<ul style="color: white;">
<!--
					<li>Orchard Park, Long Bennington, </li>
					<li>Newark, Lincolnshire </li>
					<li>NG23 5DQ, United Kingdom</li>
-->
					<li style="color: white;">Phone:&nbsp;&nbsp;&nbsp;(+91) 7908025902</li>
					<li style="color: white;">D.O.B:&nbsp;&nbsp;&nbsp;11 October 1997 </li>
					<li><a style="color: white;" href="mailto:info@example.com">Mail:&nbsp;&nbsp;&nbsp;  ashishume@gmail.com</a></li>
<!--					<li style="color: white;"><a href="#">www.sebasti.an</a></li>-->
				</ul>
			</div>
			<div class="col-md-7 contact-right">
				<h3 style="color: white;">Drop Me A Line</h3>
				<div class="stripb" style="color: white;"></div>
				<form method="post" action="">
					<input type="text" name="name" value="Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name';}" required="">
					<input type="text" name="email" value="E-mail" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'E-mail';}" required="">
					<textarea type="text" name="message" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Message';}" required="">Message</textarea>
					<input type="submit" value="SEND" name="submit_contact" style="color: white;">
				</form>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!--//contact-->
<div class="footer-top"></div>
<!--resume-->
<div class="resume text-center">
	<div class="container">
		<div class="strip text-center"><img src="images/down.png" alt=" "/></div>
		<div class="down"><a href="resume.pdf" target="_blank">Download My Resume</a></div>
	</div>
</div>
<!--//resume-->

<!--footer-->
<div class="footer">
	<div class="container">
		<p>Copyright &copy; 2018 | Ashish Dev | Axplore World</p>
	</div>
</div>
<!--//footer-->
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear'
				};
			*/

			$().UItoTop({ easingType: 'easeOutQuart' });

			});
	</script>
<!-- //here ends scrolling icon -->
</body>
</html>
